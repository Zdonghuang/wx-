
export default {
    // baseUrl: 'https://mobao.beanji.com',
    baseUrl: 'https://botue.com',
    // baseUrl: 'http://localhost:3000',
}