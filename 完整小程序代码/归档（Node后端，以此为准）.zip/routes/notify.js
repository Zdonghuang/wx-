
const express = require('express');

const db = require('../db');

const router = express.Router();

const fs = require('fs');

module.exports = router;

router.all('/', (req, res) => {

    let {xml} = req.body;

    let {openid, total_fee, out_trade_no} = xml;

    db.table('account').where({out_trade_no: out_trade_no}).find().then((row) => {
        if(row.id) {
            res.set('Content-Type', 'text/xml');
            res.send(`
                <xml>
                    <return_code><![CDATA[SUCCESS]]></return_code>
                    <return_msg><![CDATA[OK]]></return_msg>
                </xml>
            `);
            return;
        }

        // 
        db.table('user').field('id').where({openid: openid}).find().then((row) => {
            return db.table('account').add({
                uid: row.id,
                fee: total_fee / 100,
                out_trade_no: out_trade_no,
                type: 1
            });
        }).then(() => {
            res.set('Content-Type', 'text/xml');
            res.send(`
                <xml>
                    <return_code><![CDATA[SUCCESS]]></return_code>
                    <return_msg><![CDATA[OK]]></return_msg>
                </xml>
            `);
        });
    })

})
