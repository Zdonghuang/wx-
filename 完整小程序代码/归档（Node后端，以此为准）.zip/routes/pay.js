
const express = require('express');

const md5 = require('md5');

const parser = require('xml2json');

const moment = require('moment');

const db = require('../db');

const config = require('../config.json');

const router = express.Router();

module.exports = router;

router.get('/', (req, res) => {

        let ip = req.header('x-forwarded-for') || req.connection.remoteAddress,
            {uid, openid} = req.query,
            {key, mch_id} = config.wxpay,
            {appid} = config.minprogram,
            nonce_str = md5(new Date().getTime()),
            body = '按出一秒',
            out_trade_no = moment().format('YYYYMMDDHHmmssX'),
            total_fee = req.query.fee * 100,
            spbill_create_ip = ip,
            notify_url = 'https://mobao.beanji.com/notify/',
            trade_type = 'JSAPI';

        let json = {
                appid: appid,
                body: body,
                mch_id: mch_id,
                nonce_str: nonce_str,
                notify_url: notify_url,
                openid: openid,
                out_trade_no: out_trade_no,
                spbill_create_ip: spbill_create_ip,
                total_fee: total_fee,
                trade_type: trade_type
        }

        let str = '';
        for(let k in json) {
                str += k + '=' + json[k] + '&';
        }

        str += 'key=' + key;

        let sign = md5(str).toUpperCase();

        let xml = `
                <xml>
                     <appid>${appid}</appid>
                     <body>${body}</body>
                     <mch_id>${mch_id}</mch_id>
                     <nonce_str>${nonce_str}</nonce_str>
                     <notify_url>${notify_url}</notify_url>
                     <openid>${openid}</openid>
                     <out_trade_no>${out_trade_no}</out_trade_no>
                     <spbill_create_ip>${ip}</spbill_create_ip>
                     <total_fee>${total_fee}</total_fee>
                     <trade_type>JSAPI</trade_type>
                     <sign>${sign}</sign>
                </xml>
        `;

        req.axios({
                url: 'https://api.mch.weixin.qq.com/pay/unifiedorder',
                method: 'post',
                headers: {
                        'Content-Type': 'text/xml'
                },
                data: xml
        }).then((xml) => {
            let result = JSON.parse(parser.toJson(xml)).xml;
            console.log('=======');
            console.log(result);
            let timestamp = (new Date()).getTime().toString();

            let package = 'prepay_id=' + result.prepay_id;
            
            str = '';
            str += 'appId=' + result.appid;
            str += '&nonceStr=' + result.nonce_str;
            str += '&package=' + package;
            str += '&signType=MD5';
            str += '&timeStamp=' + timestamp;
            str += '&key=' + key;

            let paysign = md5(str);

            res.json({
                timeStamp: timestamp,
                nonceStr: result.nonce_str,
                package: package,
                signType: 'MD5',
                paySign: paysign
            });

        }).catch((b) => {
                console.log(b);
        }); 
})