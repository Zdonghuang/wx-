
const express = require('express');

const db = require('../db');

const router = express.Router();

module.exports = router;

router.get('/', (req, res) => {
    let {session_id, sgid} = req.query;

    req.redis.get(session_id).then((value) => {

        value = JSON.parse(value);

        let where = {
            uid: value.uid,
            gid: sgid
        }

        db.table('share').where(where).find().then((row) => {
            if(row.id) {
                return db.table('share').where(where).updateInc('times', 1);
            }

            return db.table('share').add(where);
        }).then((info) => {

            res.json({
                error: 0,
                msg: 'ok!',
                result: ''
            });
        });
    });
})