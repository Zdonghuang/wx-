
const express = require('express');

const db = require('../db');

const router = express.Router();

module.exports = router;

router.get('/', (req, res) => {

    let data = req.query;

    data.address = data.city + ' ' + data.detail;

    db.table('address').add(data).then(() => {
        // 减掉订单
        return db.table('account').add({
            uid: data.uid,
            fee: -data.cost,
            type: 3
        });
    }).then(() => {
        res.json({
            error: '',
            msg: 'ok!',
            result: ''
        });
    });

});