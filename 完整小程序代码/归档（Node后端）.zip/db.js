
const mysql = require('node-mysql-promise');

const axios = require('axios');

const config = require('./config.json');

const db = mysql.createConnection(config.mysql);

db.axios = axios;

module.exports = db;