/*
 Navicat Premium Data Transfer

 Source Server         : 123.57.227.172
 Source Server Type    : MySQL
 Source Server Version : 50639
 Source Host           : 123.57.227.172
 Source Database       : mobao

 Target Server Type    : MySQL
 Target Server Version : 50639
 File Encoding         : utf-8

 Date: 08/30/2018 09:28:48 AM
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `account`
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `fee` decimal(10,2) DEFAULT '0.00',
  `out_trade_no` char(32) NOT NULL DEFAULT '0',
  `type` enum('1','2','3') DEFAULT NULL,
  `deal_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `address`
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `name` char(16) DEFAULT NULL,
  `phone` char(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `win_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `goods`
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `cover` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
--  Records of `goods`
-- ----------------------------
BEGIN;
INSERT INTO `goods` VALUES ('1', 'Apple iPhone X (A1865) 256G 手机', '8499.00', '2.00', 'http://mobao.botue.com/uploads/item_1.jpg'), ('2', '移动联通电信100元充值卡', '99.90', '0.50', 'http://mobao.botue.com/uploads/item_2.jpg'), ('3', 'Dior迪奥烈焰蓝金唇膏3.5克', '298.00', '0.80', 'http://mobao.botue.com/uploads/item_3.jpg'), ('4', 'Kiddle Paperwhite电子阅读器：300ppi超清电子墨水触屏控 6英寸wifi 黑色', '958.00', '1.00', 'http://mobao.botue.com/uploads/item_4.jpg'), ('5', '飞利浦（philips）电吹风机HP8230家用大功率恒温护发冷热风', '139.00', '0.50', 'http://mobao.botue.com/uploads/item_5.jpg'), ('6', 'SOLOVE素乐熊吾充电宝10000毫安创意卡通可爱手机移动电源通用', '139.00', '0.60', 'http://mobao.botue.com/uploads/item_6.jpg');
COMMIT;

-- ----------------------------
--  Table structure for `share`
-- ----------------------------
DROP TABLE IF EXISTS `share`;
CREATE TABLE `share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `times` int(11) DEFAULT '1',
  `share_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
--  Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` char(28) DEFAULT NULL,
  `join_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;
