
const express = require('express');

const axios = require('axios');

const createClient = require('then-redis').createClient;

const bodyParser = require('body-parser');
 
require('body-parser-xml')(bodyParser);

const goods = require('./routes/goods');
const login = require('./routes/login');
const account = require('./routes/account');
const share = require('./routes/share');
const pay = require('./routes/pay');
const shipment = require('./routes/shipment');
const notify = require('./routes/notify');

const app = express();

const redis = createClient();

app.listen(3000);

// 拦截器
axios.interceptors.response.use(function (response) {
    return response.data;
});

app.use((req, res, next) => {
    req.axios = axios;
    next();
});

// 解析 xml 主体
app.use(bodyParser.xml({
    limit: '1MB',   // Reject payload bigger than 1 MB
    xmlParseOptions: {
        normalize: true,     // Trim whitespace inside text nodes
        normalizeTags: true, // Transform tags to lowercase
        explicitArray: false // Only put nodes in array if >1
    }
}));

app.use((req, res, next) => {
    req.redis = redis;
    next();
});

// 支付通知
app.use('/notify', notify);

app.use('/share', share);

app.use('/login', login);

// 验证是否登录
app.use((req, res, next) => {

    let session_id = req.headers['x-session'];

    // 读取session
    if(!session_id) {
        return res.json({
            error: 1,
            msg: 'Unauthorized',
            result: ''
        });
    };

    req.redis.get(session_id).then((value) => {

        value = JSON.parse(value);

        console.log(value)

        req.query = Object.assign(req.query, value);

        next();
    });
});

app.use('/goods', goods);

app.use('/account', account);

app.use('/pay', pay);

app.use('/shipment', shipment);


