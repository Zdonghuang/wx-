
const express = require('express');

const exec = require('child-process-promise').exec;

const db = require('../db');

const config = require('../config.json');

const router = express.Router();

module.exports = router;

router.get('/', (req, res) => {
    // 获取微信 code
    let code = req.query.code;

    if(!code) return;

    let session = null;

    // 获取用户 openid 
    req.axios({
        url: 'https://api.weixin.qq.com/sns/jscode2session',
        params: {
            appid: config.minprogram.appid,
            secret: config.minprogram.secret,
            js_code: code,
            grant_type: 'authorization_code'
        }
    }).then((info) => {
        // 存储 session
        session = info;

        // 检测是否为新用户
        return db.table('user').thenAdd({openid: info.openid}, {openid: info.openid}, true);

    }).then((row) => {

        session.uid = row.id;

        if(row.type == 'add') {
            // 为新用户初始免费次数
            var data = [
                {uid: row.id, gid: 1, times: 1},
                {uid: row.id, gid: 2, times: 1},
                {uid: row.id, gid: 3, times: 1},
                {uid: row.id, gid: 4, times: 1},
                {uid: row.id, gid: 5, times: 1},
                {uid: row.id, gid: 6, times: 1},
                {uid: row.id, gid: 7, times: 1},
                {uid: row.id, gid: 8, times: 1}
            ];
            
            return db.table('share').addAll(data);
        }

        return 1;

    }).then(() => {

        // 创建 3rd_session
        return exec('head -n 80 /dev/urandom | tr -dc A-Za-z0-9 | head -c 168');

    }).then((result) => {
        let session_id = result.stdout;
        
        // 存储 redis
        req.redis.set(session_id, JSON.stringify(session));

        res.json({
            error: 0,
            msg: 'ok!',
            result: {session_id: session_id}
        });
    });
});