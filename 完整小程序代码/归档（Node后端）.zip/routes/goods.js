
const express = require('express');

const db = require('../db');

const router = express.Router();

module.exports = router;

router.get('/', (req, res) => {
    // 用户id
    let uid = req.query.uid;

    // 账户总金额
    let account = 0;
    // 查询用户钱包
    db.table('account').join({
        table: 'user',
        join: 'left',
        as: 'u',
        on: ['uid', 'id']
    }).where({uid: uid, type: ['EXP', '<3']}).sum('fee').then((sum) => {
        account = sum;

        // 查询商品列表
        return db.table('goods').alias('g')
        .field('g.*, s.times as stimes')
        .join({
            table: 'share',
            join: 'left',
            as: 's',
            on: ['g.id', 's.gid']
        }).where({'s.uid': uid}).select();
    }).then((rows) => {
        rows.forEach((val) => {
            val.ptimes = Math.floor(account / val.price)
        });

        res.json({
            error: 0,
            msg: 'ok!',
            result: {
                items: rows,
                account: account
            }
        });
    });
});

router.get('/detail', (req, res) => {
    // 商品id
    let {gid, uid} = req.query;

    // 账户总金额
    let account = 0;
    // 查询用户钱包
    db.table('account').join({
        table: 'user',
        join: 'left',
        as: 'u',
        on: ['uid', 'id']
    }).where({uid: uid, type: ['EXP', '<3']}).sum('fee').then((sum) => {
        account = sum;

        // 根据商品id获取商品信息
        return db.table('goods').alias('g')
        .field('g.*, s.times as stimes')
        .join({
            table: 'share',
            join: 'left',
            as: 's',
            on: ['g.id', 's.gid']
        }).where({'s.uid': uid, 'g.id': gid}).find();
    }).then((row) => {

        row.ptimes = Math.floor(account / row.price);

        // 统计人员总数
        db.table('user').count('*').then((total) => {
            row.total = total;
            res.json(row);
        })
    });
})