
const express = require('express');

const db = require('../db');

const router = express.Router();

module.exports = router;

router.get('/', (req, res) => {
    let {ptimes, stimes, uid, gid, price} = req.query;

    // 优先消减分享
    if(stimes > 0) {
        db.table('share').where({
            gid: gid,
            uid: uid
        }).update({times: --stimes}).then((row) => {
            res.json({
                stimes: stimes,
                ptimes: ptimes
            });
        });

        return;
    }

    db.table('account').add({
        fee: -price,
        uid: uid,
        gid: gid,
        type: 2
    }).then((row) => {
        res.json({
            stimes: stimes,
            ptimes: --ptimes
        });
    });
});

router.get('/count', (req, res) => {
    let gid = req.query.gid;

    db.table('account').where({type: 1}).sum('fee').then((sum) => {
        res.json({
            error: 0,
            msg: 'ok!',
            result: sum
        });
    })
});